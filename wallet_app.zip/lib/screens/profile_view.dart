import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/notification_provider.dart';
import '../providers/navigation_provider.dart';
import '../providers/theme_provider.dart';
import '../models/user.dart';
import '../theme/app_theme.dart';

class ProfileView extends StatelessWidget {
  const ProfileView({super.key});

  @override
  Widget build(BuildContext context) {
    final userProvider = context.watch<AuthProvider>();
    final user = userProvider.currentUser;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          const SizedBox(height: 20),
          Center(
            child: GestureDetector(
              onTap: () => _showAvatarPicker(context, userProvider),
              child: Stack(
                children: [
                  CircleAvatar(
                    radius: 60,
                    backgroundColor: AppTheme.accentOrange,
                    backgroundImage: user?.avatarUrl.isNotEmpty == true 
                        ? NetworkImage(user!.avatarUrl) 
                        : null,
                    child: user?.avatarUrl.isEmpty == true
                        ? Text(
                            user?.name[0].toUpperCase() ?? 'J',
                            style: const TextStyle(fontSize: 48, color: Colors.white, fontWeight: FontWeight.bold),
                          )
                        : null,
                  ),
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: const BoxDecoration(color: AppTheme.accentGreen, shape: BoxShape.circle),
                      child: const Icon(LucideIcons.camera, size: 20, color: Colors.black),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          Text(user?.name ?? 'Loading...', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          Text(user?.email ?? '', style: const TextStyle(color: AppTheme.textGrey)),
          const SizedBox(height: 40),
          _buildMenuItem(
            icon: LucideIcons.user,
            title: 'Personal Information',
            onTap: () => _showEditProfileDialog(context, userProvider),
          ),
          _buildMenuItem(
            icon: LucideIcons.shield,
            title: 'Security',
            onTap: () => _showSecurityDialog(context),
          ),
          _buildMenuItem(
            icon: LucideIcons.bell,
            title: 'Notifications',
            onTap: () => _showNotificationsDialog(context),
          ),
          _buildMenuItem(
            icon: LucideIcons.helpCircle,
            title: 'Help & Support',
            onTap: () => _showHelpDialog(context),
          ),
          const SizedBox(height: 16),
          Consumer<ThemeProvider>(
            builder: (context, theme, child) => _buildMenuItem(
              icon: theme.isDarkMode ? LucideIcons.moon : LucideIcons.sun,
              title: theme.isDarkMode ? 'Dark Mode' : 'Light Mode',
              onTap: () => theme.toggleTheme(),
              trailing: Switch(
                value: theme.isDarkMode,
                onChanged: (_) => theme.toggleTheme(),
                activeColor: AppTheme.accentGreen,
              ),
            ),
          ),
          const SizedBox(height: 32),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () async {
                try {
                  final auth = context.read<AuthProvider>();
                  final nav = context.read<NavigationProvider>();
                  
                  await auth.logout();
                  nav.reset();
                  
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Logged out successfully')),
                    );
                  }
                } catch (e) {
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Logout failed: $e')),
                    );
                  }
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.redAccent.withOpacity(0.1),
                foregroundColor: Colors.redAccent,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                elevation: 0,
              ),
              child: const Text('Logout', style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMenuItem({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    Widget? trailing,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: AppTheme.cardDark, borderRadius: BorderRadius.circular(16)),
        child: Row(
          children: [
            Icon(icon, color: AppTheme.accentGreen, size: 20),
            const SizedBox(width: 16),
            Text(title, style: const TextStyle(fontWeight: FontWeight.w500)),
            const Spacer(),
            trailing ?? const Icon(LucideIcons.chevronRight, color: AppTheme.textGrey, size: 16),
          ],
        ),
      ),
    );
  }

  void _showEditProfileDialog(BuildContext context, AuthProvider provider) {
    final user = provider.currentUser;
    final nameController = TextEditingController(text: user?.name);
    final emailController = TextEditingController(text: user?.email);

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.cardDark,
        title: const Text('Edit Profile', style: TextStyle(color: Colors.white)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(labelText: 'Name', labelStyle: TextStyle(color: AppTheme.textGrey)),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: emailController,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(labelText: 'Email', labelStyle: TextStyle(color: AppTheme.textGrey)),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(
            onPressed: () {
              if (user != null) {
                provider.updateUser(user.copyWith(
                  name: nameController.text.trim(),
                  email: emailController.text.trim(),
                ));
              }
              Navigator.pop(ctx);
            },
            child: const Text('Save', style: TextStyle(color: AppTheme.accentGreen)),
          ),
        ],
      ),
    );
  }

  void _showSecurityDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.cardDark,
        title: const Text('Security Settings', style: TextStyle(color: Colors.white)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(LucideIcons.lock, color: AppTheme.accentYellow),
              title: const Text('Change PIN', style: TextStyle(color: Colors.white)),
              onTap: () => Navigator.pop(ctx),
            ),
            ListTile(
              leading: const Icon(LucideIcons.fingerprint, color: AppTheme.accentGreen),
              title: const Text('Biometric Authentication', style: TextStyle(color: Colors.white)),
              trailing: Switch(value: true, onChanged: (_) {}),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close')),
        ],
      ),
    );
  }

  void _showNotificationsDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) {
        final notificationProvider = context.watch<NotificationProvider>();
        return AlertDialog(
          backgroundColor: AppTheme.cardDark,
          title: const Text('Notifications', style: TextStyle(color: Colors.white)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SwitchListTile(
                title: const Text('Push Notifications', style: TextStyle(color: Colors.white)),
                subtitle: const Text('Receive alerts for transactions', style: TextStyle(color: AppTheme.textGrey, fontSize: 12)),
                value: notificationProvider.enabled,
                onChanged: (val) => notificationProvider.setEnabled(val),
                activeColor: AppTheme.accentGreen,
              ),
              ListTile(
                title: const Text('Clear All Notifications', style: TextStyle(color: Colors.white)),
                onTap: () {
                  notificationProvider.markAllRead();
                  Navigator.pop(ctx);
                },
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close')),
          ],
        );
      },
    );
  }

  void _showHelpDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.cardDark,
        title: const Text('Help & Support', style: TextStyle(color: Colors.white)),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Contact us at support@walletapp.com', style: TextStyle(color: Colors.white)),
            const SizedBox(height: 16),
            Text('Version 1.0.0', style: TextStyle(color: AppTheme.textGrey, fontSize: 12)),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Got it')),
        ],
      ),
    );
  }

  void _showAvatarPicker(BuildContext context, AuthProvider provider) {
    final avatars = [
      'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&h=200&fit=crop',
      'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop',
      'https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=200&h=200&fit=crop',
      'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&h=200&fit=crop',
      'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&h=200&fit=crop',
      'https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=200&h=200&fit=crop',
    ];

    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.cardDark,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Choose Avatar', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white)),
            const SizedBox(height: 20),
            GridView.builder(
              shrinkWrap: true,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
              ),
              itemCount: avatars.length,
              itemBuilder: (ctx, index) => GestureDetector(
                onTap: () {
                  final user = provider.currentUser;
                  if (user != null) {
                    provider.updateUser(user.copyWith(avatarUrl: avatars[index]));
                  }
                  Navigator.pop(ctx);
                },
                child: CircleAvatar(
                  backgroundImage: NetworkImage(avatars[index]),
                ),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
