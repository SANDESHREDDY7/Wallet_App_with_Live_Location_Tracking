import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../providers/transaction_provider.dart';
import '../models/transaction.dart';
import '../theme/app_theme.dart';
import '../widgets/transaction_card.dart';

class TransactionsView extends StatefulWidget {
  const TransactionsView({super.key});

  @override
  State<TransactionsView> createState() => _TransactionsViewState();
}

class _TransactionsViewState extends State<TransactionsView> {
  String _searchQuery = '';
  TransactionType? _filterType;

  @override
  Widget build(BuildContext context) {
    final txProvider = context.watch<TransactionProvider>();
    final filtered = txProvider.transactions.where((tx) {
      final matchesSearch = _searchQuery.isEmpty ||
          tx.name.toLowerCase().contains(_searchQuery.toLowerCase());
      final matchesFilter = _filterType == null || tx.type == _filterType;
      return matchesSearch && matchesFilter;
    }).toList();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Transactions', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              PopupMenuButton<TransactionType?>(
                icon: const Icon(Icons.filter_list, color: Colors.white),
                color: AppTheme.cardDark,
                onSelected: (v) => setState(() => _filterType = v),
                itemBuilder: (_) => [
                  const PopupMenuItem(value: null, child: Text('All', style: TextStyle(color: Colors.white))),
                  const PopupMenuItem(value: TransactionType.credit, child: Text('Credits', style: TextStyle(color: Colors.white))),
                  const PopupMenuItem(value: TransactionType.debit, child: Text('Debits', style: TextStyle(color: Colors.white))),
                ],
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          child: TextField(
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Search transactions...',
              hintStyle: TextStyle(color: Colors.white.withOpacity(0.3)),
              prefixIcon: const Icon(Icons.search, color: AppTheme.textGrey),
              filled: true, fillColor: AppTheme.cardDark,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
            ),
            onChanged: (v) => setState(() => _searchQuery = v),
          ),
        ),
        Expanded(
          child: txProvider.isLoading
              ? const Center(child: CircularProgressIndicator(color: AppTheme.accentGreen))
              : filtered.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(LucideIcons.inbox, size: 48, color: Colors.white.withOpacity(0.2)),
                          const SizedBox(height: 12),
                          Text('No transactions found',
                              style: TextStyle(color: Colors.white.withOpacity(0.4))),
                        ],
                      ),
                    )
                  : RefreshIndicator(
                      color: AppTheme.accentGreen,
                      onRefresh: txProvider.refresh,
                      child: ListView.separated(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                        itemCount: filtered.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 10),
                        itemBuilder: (context, i) {
                          return TransactionCard(
                            transaction: filtered[i],
                            onDelete: () => context.read<TransactionProvider>().deleteTransaction(filtered[i].id),
                          );
                        },
                      ),
                    ),
        ),
      ],
    );
  }
}
