import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../providers/cards_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/credit_card_widget.dart';
import 'scanner_screen.dart';

class CardsView extends StatelessWidget {
  const CardsView({super.key});

  @override
  Widget build(BuildContext context) {
    final cardsProvider = context.watch<CardsProvider>();
    final cards = cardsProvider.cards;

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            backgroundColor: Colors.transparent,
            floating: true,
            expandedHeight: 120,
            flexibleSpace: FlexibleSpaceBar(
              titlePadding: const EdgeInsets.only(left: 20, bottom: 16),
              title: const Text('My Wallet', 
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 24)),
              background: Container(color: Colors.transparent),
            ),
            actions: [
              Padding(
                padding: const EdgeInsets.only(right: 16),
                child: CircleAvatar(
                  backgroundColor: AppTheme.accentGreen.withOpacity(0.1),
                  child: IconButton(
                    icon: const Icon(LucideIcons.plus, color: AppTheme.accentGreen),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const ScannerScreen()),
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
          
          if (cards.isEmpty)
            const SliverFillRemaining(
              child: Center(
                child: Text('No cards added yet', style: TextStyle(color: AppTheme.textGrey)),
              ),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              sliver: SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, index) {
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 20),
                      child: CreditCardWidget(card: cards[index]),
                    );
                  },
                  childCount: cards.length,
                ),
              ),
            ),
          
          const SliverToBoxAdapter(child: SizedBox(height: 100)),
        ],
      ),
    );
  }
}
