import 'package:flutter/material.dart';
import '../widgets/expense_chart.dart';
import '../widgets/income_gauge.dart';
import '../theme/app_theme.dart';

class StatsView extends StatelessWidget {
  const StatsView({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Financial Statistics', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('Detailed overview of your income and expenses', style: TextStyle(color: AppTheme.textGrey)),
          const SizedBox(height: 32),
          const ExpenseChart(),
          const SizedBox(height: 24),
          const IncomeGauge(),
          const SizedBox(height: 32),
          _buildStatCard('Total Savings', '\$12,450.00', '+8.4%', AppTheme.accentGreen),
          const SizedBox(height: 16),
          _buildStatCard('Monthly Budget', '\$3,000.00', '65% spent', AppTheme.accentYellow),
        ],
      ),
    );
  }

  Widget _buildStatCard(String title, String value, String subtitle, Color accentColor) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: AppTheme.cardDark, borderRadius: BorderRadius.circular(24)),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: accentColor.withOpacity(0.1), shape: BoxShape.circle),
            child: Icon(Icons.trending_up, color: accentColor),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(color: AppTheme.textGrey, fontSize: 13)),
                const SizedBox(height: 4),
                Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ],
            ),
          ),
          Text(subtitle, style: TextStyle(color: accentColor, fontWeight: FontWeight.bold, fontSize: 12)),
        ],
      ),
    );
  }
}
