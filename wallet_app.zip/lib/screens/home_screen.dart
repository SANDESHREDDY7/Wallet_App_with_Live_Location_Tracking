import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../repositories/preferences_repository.dart';
import '../providers/wallet_provider.dart';
import '../providers/transaction_provider.dart';
import '../providers/navigation_provider.dart';
import 'dashboard_view.dart';
import 'transactions_view.dart';
import 'stats_view.dart';
import 'profile_view.dart';
import 'scanner_screen.dart';
import 'cards_view.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _loadLastTab();
  }

  Future<void> _loadLastTab() async {
    final lastTab = await PreferencesRepository.instance.getLastTab();
    if (mounted) {
      context.read<NavigationProvider>().setIndex(lastTab);
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _refreshData();
    }
  }

  Future<void> _refreshData() async {
    if (!mounted) return;
    await Future.wait([
      context.read<WalletProvider>().load(),
      context.read<TransactionProvider>().fetchTransactions(),
    ]);
  }

  final List<Widget> _pages = [
    const DashboardView(key: PageStorageKey('dashboard')),
    const TransactionsView(key: PageStorageKey('transactions')),
    const CardsView(key: PageStorageKey('cards')),
    const StatsView(key: PageStorageKey('stats')),
    const ProfileView(key: PageStorageKey('profile')),
  ];

  @override
  Widget build(BuildContext context) {
    final nav = context.watch<NavigationProvider>();
    return Scaffold(
      body: SafeArea(
        child: IndexedStack(
          index: nav.selectedIndex,
          children: _pages,
        ),
      ),
      bottomNavigationBar: _buildBottomBar(nav),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const ScannerScreen()),
        ),
        backgroundColor: AppTheme.accentGreen,
        shape: const CircleBorder(),
        child: const Icon(LucideIcons.scan, color: Colors.black),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }

  Widget _buildBottomBar(NavigationProvider nav) {
    return BottomAppBar(
      color: Colors.black,
      shape: const CircularNotchedRectangle(),
      notchMargin: 8,
      child: SizedBox(
        height: 60,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  _buildNavItem(nav, 0, LucideIcons.home),
                  _buildNavItem(nav, 1, LucideIcons.list),
                ],
              ),
              const SizedBox(width: 40),
              Row(
                children: [
                  _buildNavItem(nav, 2, LucideIcons.creditCard),
                  _buildNavItem(nav, 3, LucideIcons.pieChart),
                  _buildNavItem(nav, 4, LucideIcons.user),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem(NavigationProvider nav, int index, IconData icon) {
    final isSelected = nav.selectedIndex == index;
    return IconButton(
      icon: Icon(icon, color: isSelected ? Colors.white : AppTheme.textGrey),
      onPressed: () {
        nav.setIndex(index);
        PreferencesRepository.instance.setLastTab(index);
      },
    );
  }

}
