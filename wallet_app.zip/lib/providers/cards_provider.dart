import 'package:flutter/material.dart';

class PaymentCard {
  final String id;
  final String cardNumber;
  final String holderName;
  final String expiryDate;
  final String cvv;
  final CardType type;
  final Color color;

  PaymentCard({
    required this.id,
    required this.cardNumber,
    required this.holderName,
    required this.expiryDate,
    required this.cvv,
    required this.type,
    required this.color,
  });
}

enum CardType { visa, mastercard, amex }

class CardsProvider with ChangeNotifier {
  final List<PaymentCard> _cards = [
    PaymentCard(
      id: '1',
      cardNumber: '4532 1234 5678 9012',
      holderName: 'SANDESH REDDY',
      expiryDate: '12/26',
      cvv: '123',
      type: CardType.visa,
      color: const Color(0xFF1A1A1A),
    ),
    PaymentCard(
      id: '2',
      cardNumber: '5412 8888 9999 1111',
      holderName: 'SANDESH REDDY',
      expiryDate: '09/25',
      cvv: '456',
      type: CardType.mastercard,
      color: const Color(0xFF2D3436),
    ),
  ];

  List<PaymentCard> get cards => [..._cards];

  void addCard(PaymentCard card) {
    _cards.add(card);
    notifyListeners();
  }

  void removeCard(String id) {
    _cards.removeWhere((c) => c.id == id);
    notifyListeners();
  }
}
