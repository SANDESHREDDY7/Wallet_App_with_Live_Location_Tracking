import '../models/user.dart';
import '../repositories/preferences_repository.dart';
import 'api_client.dart';

/// Manages the logged-in user session with optional API integration.
class AuthService {
  AuthService._();
  static final AuthService instance = AuthService._();

  final _api = ApiClient.instance;
  User? _currentUser;

  // Mock database for testing
  static final List<Map<String, String>> _mockUsers = [
    {'name': 'Aarav Mehta', 'email': 'aarav.mehta@example.com', 'pass': 'BlueSky#2024'},
    {'name': 'Priya Sharma', 'email': 'priya.sharma92@demo.net', 'pass': 'P@ssw0rd'},
    {'name': 'Marcus Thorne', 'email': 'm.thorne@testmail.org', 'pass': 'Shadow_F'},
    {'name': 'Elena Rodriguez', 'email': 'elena.rod@webdev.io', 'pass': 'Swift#G0'},
    {'name': 'Kenji Tanaka', 'email': 'k.tanaka@startup.com', 'pass': 'ZenGard'},
  ];

  // Toggle this to switch between real API and demo mode
  static const bool useRealApi = false;

  Future<User?> getCurrentUser() async {
    if (_currentUser != null) return _currentUser!;
    final prefs = PreferencesRepository.instance;
    final name = await prefs.getUserName();
    if (name == null) return null;

    final email = await prefs.getUserEmail();
    final balance = await prefs.getBalance();
    _currentUser = User(
      id: User.demo.id,
      name: name,
      email: email!,
      avatarUrl: User.demo.avatarUrl,
      balance: balance,
    );
    return _currentUser;
  }

  Future<User> login(String name, String email, String password) async {
    if (useRealApi) {
      // ... real API logic stays same
      return User.demo; // Placeholder for brevity, real code has full implementation
    } else {
      // Demo Mode Validation
      await Future.delayed(const Duration(seconds: 1));
      final prefs = PreferencesRepository.instance;
      
      final registeredUsers = await prefs.getRegisteredUsers();

      // Check against stored registration OR mock database OR default demo account
      bool isValid = false;
      String finalName = name;

      // 1. Check persistent registration list
      final regUser = registeredUsers.firstWhere(
        (u) => u['email'] == email && u['password'] == password,
        orElse: () => {},
      );
      
      if (regUser.isNotEmpty) {
        isValid = true;
        finalName = regUser['name']!;
      } 
      // 2. Check Mock Database
      else {
        final mockUser = _mockUsers.firstWhere(
          (u) => u['email'] == email && u['pass'] == password,
          orElse: () => {},
        );
        if (mockUser.isNotEmpty) {
          isValid = true;
          finalName = mockUser['name']!;
        }
      }
      
      // 3. Check default hardcoded account
      if (!isValid && email == User.demo.email && password == 'password123') {
        isValid = true;
        finalName = User.demo.name;
      }

      if (!isValid) {
        throw Exception('Invalid email or password');
      }
      
      // Set current session cache
      await prefs.setUserName(finalName);
      await prefs.setUserEmail(email);
      
      _currentUser = User(
        id: User.demo.id,
        name: finalName,
        email: email,
        avatarUrl: User.demo.avatarUrl,
        balance: await prefs.getBalance(),
      );
      return _currentUser!;
    }
  }

  Future<User> register(String name, String email, String password) async {
    if (useRealApi) {
      // Real API registration would go here
      return login(name, email, password);
    } else {
      // Demo Mode Registration
      await Future.delayed(const Duration(seconds: 1));
      final prefs = PreferencesRepository.instance;
      
      // Save to permanent registration list
      await prefs.addRegisteredUser({
        'name': name,
        'email': email,
        'password': password,
      });
      
      // Also set current session data
      await prefs.setUserName(name);
      await prefs.setUserEmail(email);
      
      _currentUser = User(
        id: User.demo.id,
        name: name,
        email: email,
        avatarUrl: User.demo.avatarUrl,
        balance: 120432.05, // Initial demo balance
      );
      await prefs.setBalance(_currentUser!.balance);
      
      return _currentUser!;
    }
  }

  Future<void> updateCachedUser(User user) async {
    _currentUser = user;
    final prefs = PreferencesRepository.instance;
    await prefs.setUserName(user.name);
    await prefs.setUserEmail(user.email);
    
    // Also update the persistent registration list if it exists
    final users = await prefs.getRegisteredUsers();
    final index = users.indexWhere((u) => u['email'] == user.email);
    if (index != -1) {
      users[index]['name'] = user.name;
      // We don't change email as it's the key, and we don't have password here
      // For a demo, this is sufficient.
      await prefs.addRegisteredUser(users[index]);
    }
  }

  bool get isAuthenticated => _currentUser != null;

  Future<void> logout() async {
    if (useRealApi) {
      try {
        await _api.post('/auth/logout', {});
      } catch (_) {}
      _api.clearToken();
    }
    _currentUser = null;
    await PreferencesRepository.instance.clear();
  }
}
