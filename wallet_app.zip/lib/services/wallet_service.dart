import '../models/expense_data.dart';
import '../models/income_stats.dart';
import '../repositories/preferences_repository.dart';

/// Business logic for wallet balance and financial stats.
class WalletService {
  WalletService._();
  static final WalletService instance = WalletService._();

  final _prefs = PreferencesRepository.instance;

  // ---------------------------------------------------------------------------
  // Balance
  // ---------------------------------------------------------------------------

  Future<double> getBalance() => _prefs.getBalance();

  /// Add money to the wallet. Returns the new balance.
  Future<double> addMoney(double amount) async {
    if (amount <= 0) throw ArgumentError('Amount must be positive');
    final current = await _prefs.getBalance();
    final newBalance = current + amount;
    await _prefs.setBalance(newBalance);
    return newBalance;
  }

  /// Deduct money from the wallet. Returns the new balance.
  Future<double> deductMoney(double amount) async {
    if (amount <= 0) throw ArgumentError('Amount must be positive');
    final current = await _prefs.getBalance();
    if (current < amount) throw StateError('Insufficient funds');
    final newBalance = current - amount;
    await _prefs.setBalance(newBalance);
    return newBalance;
  }

  // ---------------------------------------------------------------------------
  // Stats
  // ---------------------------------------------------------------------------

  /// Returns mock income stats. In production, call a real API here.
  Future<IncomeStats> getIncomeStats() async {
    return const IncomeStats(
      annualIncome: 8874.00,
      growthPercent: 30.0,
      weeklyTotal: 22400.25,
    );
  }

  /// Returns weekly expense bar-chart data calculated from current week.
  Future<List<ExpenseData>> getWeeklyExpenses() async {
    // In production these would come from the DB aggregate query.
    return const [
      ExpenseData(day: 'Sun', amount: 10),
      ExpenseData(day: 'Mon', amount: 15),
      ExpenseData(day: 'Tue', amount: 8),
      ExpenseData(day: 'Wed', amount: 18),
      ExpenseData(day: 'Thu', amount: 12),
      ExpenseData(day: 'Fri', amount: 16),
      ExpenseData(day: 'Sat', amount: 11),
    ];
  }
}
