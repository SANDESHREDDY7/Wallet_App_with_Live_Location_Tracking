import '../repositories/preferences_repository.dart';
import '../models/notification_item.dart';

class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  final _prefs = PreferencesRepository.instance;

  Future<int> getUnreadCount() => _prefs.getUnreadCount();

  Future<void> markAllRead() => _prefs.markAllRead();

  Future<bool> isEnabled() => _prefs.getNotificationsEnabled();

  Future<void> setEnabled(bool enabled) =>
      _prefs.setNotificationsEnabled(enabled);

  Future<List<NotificationItem>> getNotifications() async {
    // Mock data for demo
    return [
      NotificationItem(
        id: '1',
        title: 'Payment Received',
        message: 'You received \$450.00 from James John',
        timestamp: DateTime.now().subtract(const Duration(minutes: 15)),
        type: 'transaction',
        isRead: false,
      ),
      NotificationItem(
        id: '2',
        title: 'Security Alert',
        message: 'New login detected from a Chrome browser on Windows',
        timestamp: DateTime.now().subtract(const Duration(hours: 2)),
        type: 'security',
        isRead: false,
      ),
      NotificationItem(
        id: '3',
        title: 'System Update',
        message: 'Wallet App v2.4 is now available with new features',
        timestamp: DateTime.now().subtract(const Duration(days: 1)),
        type: 'system',
        isRead: false,
      ),
      NotificationItem(
        id: '4',
        title: 'Transfer Successful',
        message: 'Your transfer of \$120.00 to Sarah was successful',
        timestamp: DateTime.now().subtract(const Duration(days: 2)),
        type: 'transaction',
        isRead: true,
      ),
    ];
  }
}
