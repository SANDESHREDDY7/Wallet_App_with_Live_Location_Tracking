import '../models/contact.dart';
import '../repositories/local_db.dart';

/// Business logic for managing quick-transfer contacts.
class ContactService {
  ContactService._();
  static final ContactService instance = ContactService._();

  final _db = LocalDb.instance;

  Future<List<Contact>> getContacts() => _db.getAllContacts();

  Future<void> addContact(Contact contact) => _db.insertContact(contact);

  Future<void> removeContact(String id) => _db.deleteContact(id);

  /// Create a new contact with a generated id.
  Future<Contact> createContact({
    required String name,
    String avatarUrl = '',
    String? phone,
    String? email,
  }) async {
    final c = Contact(
      id: 'c_${DateTime.now().millisecondsSinceEpoch}',
      name: name,
      avatarUrl: avatarUrl,
      phone: phone,
      email: email,
    );
    await _db.insertContact(c);
    return c;
  }
}
