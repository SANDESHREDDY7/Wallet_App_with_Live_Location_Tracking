import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  static const Color bgDark = Color(0xFF0F0F0F);
  static const Color cardDark = Color(0xFF1A1A1A);
  static const Color accentOrange = Color(0xFFFF6B00);
  static const Color accentYellow = Color(0xFFFFD600);
  static const Color accentGreen = Color(0xFFBFFF00);
  static const Color textWhite = Colors.white;
  static const Color textGrey = Color(0xFF8E8E93);

  static ThemeData darkTheme = ThemeData(
    brightness: Brightness.dark,
    scaffoldBackgroundColor: bgDark,
    primaryColor: accentOrange,
    colorScheme: const ColorScheme.dark(
      primary: accentOrange,
      secondary: accentYellow,
      surface: cardDark,
      background: bgDark,
    ),
    textTheme: GoogleFonts.outfitTextTheme(
      const TextTheme(
        headlineLarge: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: textWhite),
        headlineMedium: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: textWhite),
        bodyLarge: TextStyle(fontSize: 16, color: textWhite),
        bodyMedium: TextStyle(fontSize: 14, color: textGrey),
      ),
    ),
  );

  static ThemeData lightTheme = ThemeData(
    brightness: Brightness.light,
    scaffoldBackgroundColor: const Color(0xFFF8F8F8),
    primaryColor: accentGreen,
    colorScheme: const ColorScheme.light(
      primary: accentGreen,
      secondary: accentOrange,
      surface: Colors.white,
      background: Color(0xFFF8F8F8),
    ),
    textTheme: GoogleFonts.outfitTextTheme(
      const TextTheme(
        headlineLarge: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.black),
        headlineMedium: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.black),
        bodyLarge: TextStyle(fontSize: 16, color: Colors.black),
        bodyMedium: TextStyle(fontSize: 14, color: Color(0xFF666666)),
      ),
    ),
  );

  static LinearGradient primaryGradient = const LinearGradient(
    colors: [accentOrange, Color(0xFFFFB800)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static LinearGradient whiteGradient = const LinearGradient(
    colors: [Colors.white, Color(0xFFF0F0F0)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}
