import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/wallet_provider.dart';
import '../providers/navigation_provider.dart';
import '../theme/app_theme.dart';
import '../screens/add_money_screen.dart';
import '../screens/send_money_screen.dart';
import '../screens/pay_bill_screen.dart';

class BalanceCard extends StatelessWidget {
  const BalanceCard({super.key});

  @override
  Widget build(BuildContext context) {
    final wallet = context.watch<WalletProvider>();
    return Container(
      width: double.infinity,
      height: 220,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AppTheme.accentOrange, AppTheme.accentYellow, Colors.white],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          stops: [0.0, 0.5, 1.0],
        ),
        borderRadius: BorderRadius.circular(32),
      ),
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Current Balance',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Colors.black.withOpacity(0.6),
                  fontWeight: FontWeight.w600,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppTheme.accentGreen,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Text('+12%',
                    style: TextStyle(color: Colors.black, fontSize: 12, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
          const SizedBox(height: 8),
          wallet.isLoading
              ? const SizedBox(
                  height: 44,
                  child: Center(child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2)))
              : Text(
                  wallet.formattedBalance,
                  style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                    color: Colors.black,
                    fontSize: 36,
                    letterSpacing: -1,
                  ),
                ),
          const Spacer(),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildGlassButton(
                icon: Icons.add,
                label: 'Add Money',
                onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (_) => const AddMoneyScreen())),
              ),
              _buildGlassButton(
                icon: Icons.swap_horiz,
                label: 'Transfer',
                onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (_) => const SendMoneyScreen())),
              ),
              _buildGlassButton(
                icon: Icons.receipt_long,
                label: 'Pay Bill',
                onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (_) => const PayBillScreen())),
              ),
              _buildGlassButton(
                icon: Icons.settings,
                label: 'Setting',
                onTap: () => context.read<NavigationProvider>().setIndex(3),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildGlassButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.white.withOpacity(0.2)),
                ),
                child: Icon(icon, color: Colors.black, size: 20),
              ),
            ),
          ),
          const SizedBox(height: 4),
          Text(label,
              style: const TextStyle(color: Colors.black, fontSize: 10, fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }
}
