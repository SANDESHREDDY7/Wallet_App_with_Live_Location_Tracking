import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/wallet_provider.dart';
import '../theme/app_theme.dart';

class IncomeGauge extends StatelessWidget {
  const IncomeGauge({super.key});

  @override
  Widget build(BuildContext context) {
    final wallet = context.watch<WalletProvider>();
    final stats = wallet.incomeStats;
    final growth = stats?.growthPercent ?? 30.0;
    final remaining = 100 - growth;
    final annualIncome = stats != null
        ? '\$${stats.annualIncome.toStringAsFixed(0)}'
        : '\$0';

    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppTheme.cardDark,
        borderRadius: BorderRadius.circular(32),
        border: Border.all(color: Colors.white.withOpacity(0.05)),
      ),
      child: Column(
        children: [
          SizedBox(
            height: 180,
            child: Stack(
              alignment: Alignment.center,
              children: [
                PieChart(
                  PieChartData(
                    startDegreeOffset: 180,
                    sectionsSpace: 0,
                    centerSpaceRadius: 70,
                    sections: [
                      PieChartSectionData(
                        color: AppTheme.accentYellow,
                        value: growth,
                        showTitle: false,
                        radius: 12,
                        badgeWidget: Text(
                          '↑ ${growth.toStringAsFixed(0)}%',
                          style: const TextStyle(fontSize: 10, color: Colors.white),
                        ),
                        badgePositionPercentageOffset: 1.5,
                      ),
                      PieChartSectionData(
                        color: Colors.white.withOpacity(0.05),
                        value: remaining,
                        showTitle: false,
                        radius: 12,
                      ),
                    ],
                  ),
                ),
                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('Annual Income',
                        style: TextStyle(color: AppTheme.textGrey, fontSize: 12)),
                    const SizedBox(height: 8),
                    wallet.isLoading
                        ? const CircularProgressIndicator(
                            color: AppTheme.accentGreen, strokeWidth: 2)
                        : Text(annualIncome,
                            style: Theme.of(context).textTheme.headlineMedium),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildControlCircle(Icons.play_arrow, () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Starting live income sync...'), behavior: SnackBarBehavior.floating),
                );
              }),
              _buildControlCircle(Icons.pause, () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Income sync paused.'), behavior: SnackBarBehavior.floating),
                );
              }),
              _buildControlCircle(Icons.info_outline, () {
                _showInfoDialog(context);
              }),
              _buildControlCircle(Icons.settings, () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Opening gauge settings...'), behavior: SnackBarBehavior.floating),
                );
              }),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildControlCircle(IconData icon, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(32),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.05),
          shape: BoxShape.circle,
        ),
        child: Icon(icon, color: Colors.white, size: 20),
      ),
    );
  }

  void _showInfoDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.cardDark,
        title: const Text('Income Statistics', style: TextStyle(color: Colors.white)),
        content: const Text(
          'This gauge shows your estimated annual income based on your transaction history and growth trends.',
          style: TextStyle(color: AppTheme.textGrey),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close')),
        ],
      ),
    );
  }
}
