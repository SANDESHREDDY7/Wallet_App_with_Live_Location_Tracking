import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../providers/wallet_provider.dart';
import '../providers/transaction_provider.dart';
import '../theme/app_theme.dart';

class QuickActions extends StatelessWidget {
  const QuickActions({super.key});

  @override
  Widget build(BuildContext context) {
    final actions = [
      _ActionItem(
        label: 'Recharge',
        icon: LucideIcons.smartphone,
        onTap: () => _showRechargeSheet(context),
      ),
      _ActionItem(
        label: 'Charity',
        icon: LucideIcons.heart,
        onTap: () => _showDonateSheet(context),
      ),
      _ActionItem(
        label: 'Loan',
        icon: LucideIcons.wallet,
        onTap: () => _showLoanSheet(context),
      ),
      _ActionItem(
        label: 'Bank to Bank',
        icon: LucideIcons.landmark,
        onTap: () => _showBankTransferSheet(context),
      ),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Quick Action',
                style: Theme.of(context)
                    .textTheme
                    .bodyLarge
                    ?.copyWith(fontWeight: FontWeight.bold)),
            const Text('See all', style: TextStyle(fontSize: 12, color: AppTheme.textGrey)),
          ],
        ),
        const SizedBox(height: 16),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: actions
              .map((a) => _buildActionButton(context, a))
              .toList(),
        ),
      ],
    );
  }

  Widget _buildActionButton(BuildContext context, _ActionItem action) {
    return GestureDetector(
      onTap: action.onTap,
      child: Column(
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: const BoxDecoration(color: AppTheme.cardDark, shape: BoxShape.circle),
            child: Icon(action.icon, color: Colors.white, size: 24),
          ),
          const SizedBox(height: 8),
          Text(action.label,
              style: const TextStyle(fontSize: 10, color: AppTheme.textGrey),
              textAlign: TextAlign.center),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Bottom sheets for each quick action
  // ---------------------------------------------------------------------------

  void _showRechargeSheet(BuildContext context) {
    final amountCtrl = TextEditingController();
    final phoneCtrl = TextEditingController();
    _showActionSheet(
      context: context,
      title: 'Recharge',
      accentColor: Colors.cyanAccent,
      fields: [
        _SheetField(controller: phoneCtrl, hint: 'Phone number', isNumeric: false),
        _SheetField(controller: amountCtrl, hint: 'Amount (\$)', isNumeric: true),
      ],
      onConfirm: () async {
        final amount = double.tryParse(amountCtrl.text.trim()) ?? 0;
        if (amount <= 0) return;
        await context.read<WalletProvider>().recharge(
              operator: 'Mobile',
              amount: amount,
              phone: phoneCtrl.text.trim(),
            );
        await context.read<TransactionProvider>().refresh();
      },
      buttonLabel: 'Recharge Now',
      buttonColor: Colors.cyanAccent,
    );
  }

  void _showDonateSheet(BuildContext context) {
    final amountCtrl = TextEditingController();
    final causeCtrl = TextEditingController();
    _showActionSheet(
      context: context,
      title: 'Charity Donation',
      accentColor: Colors.pinkAccent,
      fields: [
        _SheetField(controller: causeCtrl, hint: 'Cause / Organisation', isNumeric: false),
        _SheetField(controller: amountCtrl, hint: 'Amount (\$)', isNumeric: true),
      ],
      onConfirm: () async {
        final amount = double.tryParse(amountCtrl.text.trim()) ?? 0;
        if (amount <= 0) return;
        await context.read<WalletProvider>().donate(
              cause: causeCtrl.text.trim().isEmpty ? 'Charity' : causeCtrl.text.trim(),
              amount: amount,
            );
        await context.read<TransactionProvider>().refresh();
      },
      buttonLabel: 'Donate',
      buttonColor: Colors.pinkAccent,
    );
  }

  void _showLoanSheet(BuildContext context) {
    final amountCtrl = TextEditingController();
    final providerCtrl = TextEditingController();
    _showActionSheet(
      context: context,
      title: 'Receive Loan',
      accentColor: Colors.purpleAccent,
      fields: [
        _SheetField(controller: providerCtrl, hint: 'Loan provider', isNumeric: false),
        _SheetField(controller: amountCtrl, hint: 'Loan amount (\$)', isNumeric: true),
      ],
      onConfirm: () async {
        final amount = double.tryParse(amountCtrl.text.trim()) ?? 0;
        if (amount <= 0) return;
        await context.read<WalletProvider>().receiveLoan(
              amount: amount,
              provider: providerCtrl.text.trim().isEmpty ? 'Bank' : providerCtrl.text.trim(),
            );
        await context.read<TransactionProvider>().refresh();
      },
      buttonLabel: 'Receive Loan',
      buttonColor: Colors.purpleAccent,
    );
  }

  void _showBankTransferSheet(BuildContext context) {
    final amountCtrl = TextEditingController();
    final bankCtrl = TextEditingController();
    final noteCtrl = TextEditingController();
    _showActionSheet(
      context: context,
      title: 'Bank to Bank',
      accentColor: Colors.tealAccent,
      fields: [
        _SheetField(controller: bankCtrl, hint: 'Bank / Account name', isNumeric: false),
        _SheetField(controller: amountCtrl, hint: 'Amount (\$)', isNumeric: true),
        _SheetField(controller: noteCtrl, hint: 'Note (optional)', isNumeric: false),
      ],
      onConfirm: () async {
        final amount = double.tryParse(amountCtrl.text.trim()) ?? 0;
        if (amount <= 0) return;
        await context.read<WalletProvider>().bankTransfer(
              bankName: bankCtrl.text.trim().isEmpty ? 'Bank' : bankCtrl.text.trim(),
              amount: amount,
              note: noteCtrl.text.trim().isEmpty ? null : noteCtrl.text.trim(),
            );
        await context.read<TransactionProvider>().refresh();
      },
      buttonLabel: 'Transfer',
      buttonColor: Colors.tealAccent,
    );
  }

  void _showActionSheet({
    required BuildContext context,
    required String title,
    required Color accentColor,
    required List<_SheetField> fields,
    required Future<void> Function() onConfirm,
    required String buttonLabel,
    required Color buttonColor,
  }) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.cardDark,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
            left: 24, right: 24, top: 24,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 4, height: 24,
                  decoration: BoxDecoration(
                      color: accentColor, borderRadius: BorderRadius.circular(2)),
                ),
                const SizedBox(width: 12),
                Text(title,
                    style: const TextStyle(
                        fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white)),
              ],
            ),
            const SizedBox(height: 20),
            ...fields.map((f) => Padding(
                  padding: const EdgeInsets.only(bottom: 14),
                  child: TextField(
                    controller: f.controller,
                    keyboardType: f.isNumeric
                        ? const TextInputType.numberWithOptions(decimal: true)
                        : TextInputType.text,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      hintText: f.hint,
                      hintStyle: TextStyle(color: Colors.white.withOpacity(0.3)),
                      filled: true, fillColor: AppTheme.bgDark,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14),
                          borderSide: BorderSide.none),
                    ),
                  ),
                )),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity, height: 52,
              child: ElevatedButton(
                onPressed: () async {
                  try {
                    await onConfirm();
                    if (ctx.mounted) {
                      Navigator.pop(ctx);
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text('$title completed!'),
                        backgroundColor: accentColor.withOpacity(0.8),
                        behavior: SnackBarBehavior.floating,
                      ));
                    }
                  } catch (e) {
                    if (ctx.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text('Error: $e'),
                        backgroundColor: Colors.redAccent,
                        behavior: SnackBarBehavior.floating,
                      ));
                    }
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: buttonColor,
                  foregroundColor: Colors.black,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                child: Text(buttonLabel,
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ActionItem {
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  const _ActionItem({required this.label, required this.icon, required this.onTap});
}

class _SheetField {
  final TextEditingController controller;
  final String hint;
  final bool isNumeric;
  const _SheetField({required this.controller, required this.hint, required this.isNumeric});
}
