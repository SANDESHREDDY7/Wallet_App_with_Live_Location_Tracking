import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/transaction.dart';
import '../models/contact.dart';

// Conditionally import the web factory only on web
import 'local_db_web_worker.dart' if (dart.library.io) 'local_db_native_worker.dart';

class LocalDb {
  LocalDb._();
  static final LocalDb instance = LocalDb._();

  Database? _db;
  bool _isWebStorage = false;
  Completer<void>? _initCompleter;
  
  // Web storage cache
  List<WalletTransaction> _webTransactions = [];
  List<Contact> _webContacts = [];

  Future<void> init() async {
    if (_db != null || _isWebStorage) return;
    if (_initCompleter != null) return _initCompleter!.future;

    _initCompleter = Completer<void>();

    try {
      if (kIsWeb) {
        // For web, use SharedPreferences as a reliable persistent "database"
        // This avoids WASM/Worker issues while maintaining persistence.
        _isWebStorage = true;
        await _loadWebStorage();
        _initCompleter!.complete();
        return;
      }

      // Native SQLite path
      final dbPath = await getDatabasesPath();
      final path = join(dbPath, 'wallet.db');
      
      _db = await openDatabase(
        path, 
        version: 1, 
        onCreate: _onCreate,
      ).timeout(const Duration(seconds: 5));
      
      _initCompleter!.complete();
    } catch (e) {
      // Fallback for any other environment issues
      _isWebStorage = true;
      _seedDemoData();
      _initCompleter!.complete();
    }
  }

  Future<void> _loadWebStorage() async {
    final prefs = await SharedPreferences.getInstance();
    
    final txJson = prefs.getString('web_db_transactions');
    if (txJson != null) {
      final List decoded = jsonDecode(txJson);
      _webTransactions = decoded.map((e) => WalletTransaction.fromMap(e)).toList();
    } else {
      _seedDemoData();
    }

    final contactJson = prefs.getString('web_db_contacts');
    if (contactJson != null) {
      final List decoded = jsonDecode(contactJson);
      _webContacts = decoded.map((e) => Contact.fromMap(e)).toList();
    } else if (txJson == null) {
      _webContacts = List.from(Contact.seeds);
    }
    
    await _saveWebStorage();
  }

  Future<void> _saveWebStorage() async {
    if (!kIsWeb) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('web_db_transactions', jsonEncode(_webTransactions.map((e) => e.toMap()).toList()));
    await prefs.setString('web_db_contacts', jsonEncode(_webContacts.map((e) => e.toMap()).toList()));
  }

  void _seedDemoData() {
    final now = DateTime.now();
    _webTransactions = [
      WalletTransaction(id: 'tx_001', name: 'Spotify Premium', amount: 9.99, type: TransactionType.debit, category: TransactionCategory.entertainment, date: now.subtract(const Duration(days: 1)), note: 'Monthly subscription'),
      WalletTransaction(id: 'tx_002', name: 'Amazon Prime', amount: 12.99, type: TransactionType.debit, category: TransactionCategory.shopping, date: now.subtract(const Duration(days: 1))),
      WalletTransaction(id: 'tx_003', name: 'PayPal Transfer', amount: 100.00, type: TransactionType.credit, category: TransactionCategory.transfer, date: now.subtract(const Duration(days: 1)), note: 'Received from client'),
    ];
    _webContacts = List.from(Contact.seeds);
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE transactions (
        id TEXT PRIMARY KEY, name TEXT NOT NULL, amount REAL NOT NULL,
        type INTEGER NOT NULL, category INTEGER NOT NULL,
        date TEXT NOT NULL, note TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE contacts (
        id TEXT PRIMARY KEY, name TEXT NOT NULL, avatarUrl TEXT NOT NULL,
        phone TEXT, email TEXT
      )
    ''');
    await _seed(db);
  }

  Future<void> _seed(Database db) async {
    final now = DateTime.now();
    final seeds = [
      WalletTransaction(id: 'tx_001', name: 'Spotify Premium', amount: 9.99, type: TransactionType.debit, category: TransactionCategory.entertainment, date: now.subtract(const Duration(days: 1)), note: 'Monthly subscription'),
      WalletTransaction(id: 'tx_002', name: 'Amazon Prime', amount: 12.99, type: TransactionType.debit, category: TransactionCategory.shopping, date: now.subtract(const Duration(days: 1))),
      WalletTransaction(id: 'tx_003', name: 'PayPal Transfer', amount: 100.00, type: TransactionType.credit, category: TransactionCategory.transfer, date: now.subtract(const Duration(days: 1)), note: 'Received from client'),
    ];
    for (final tx in seeds) {
      await db.insert('transactions', tx.toMap(), conflictAlgorithm: ConflictAlgorithm.ignore);
    }
    for (final c in Contact.seeds) {
      await db.insert('contacts', c.toMap(), conflictAlgorithm: ConflictAlgorithm.ignore);
    }
  }

  Future<List<WalletTransaction>> getAllTransactions() async {
    await init();
    if (_isWebStorage) return List.unmodifiable(_webTransactions);
    final rows = await _db!.query('transactions', orderBy: 'date DESC');
    return rows.map(WalletTransaction.fromMap).toList();
  }

  Future<void> insertTransaction(WalletTransaction tx) async {
    await init();
    if (_isWebStorage) {
      _webTransactions.removeWhere((t) => t.id == tx.id);
      _webTransactions.insert(0, tx);
      await _saveWebStorage();
      return;
    }
    await _db!.insert('transactions', tx.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> deleteTransaction(String id) async {
    await init();
    if (_isWebStorage) {
      _webTransactions.removeWhere((t) => t.id == id);
      await _saveWebStorage();
      return;
    }
    await _db!.delete('transactions', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Contact>> getAllContacts() async {
    await init();
    if (_isWebStorage) return List.unmodifiable(_webContacts);
    final rows = await _db!.query('contacts', orderBy: 'name ASC');
    return rows.map(Contact.fromMap).toList();
  }

  Future<void> insertContact(Contact c) async {
    await init();
    if (_isWebStorage) {
      _webContacts.removeWhere((x) => x.id == c.id);
      _webContacts.add(c);
      await _saveWebStorage();
      return;
    }
    await _db!.insert('contacts', c.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> deleteContact(String id) async {
    await init();
    if (_isWebStorage) {
      _webContacts.removeWhere((c) => c.id == id);
      await _saveWebStorage();
      return;
    }
    await _db!.delete('contacts', where: 'id = ?', whereArgs: [id]);
  }
}
