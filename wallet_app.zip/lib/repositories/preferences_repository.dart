import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

/// Stores lightweight key/value data: balance, user profile, settings.
class PreferencesRepository {
  PreferencesRepository._();
  static final PreferencesRepository instance = PreferencesRepository._();

  static const _keyBalance = 'wallet_balance';
  static const _keyUserName = 'user_name';
  static const _keyUserEmail = 'user_email';
  
  // Multiple registration data (persists after logout)
  static const _keyRegisteredUsers = 'registered_users';
  
  static const _keyNotificationsEnabled = 'notifications_enabled';
  static const _keyUnreadCount = 'unread_count';
  static const _keyLastTab = 'last_nav_tab';

  // ---------------------------------------------------------------------------
  // Balance
  // ---------------------------------------------------------------------------

  Future<double> getBalance() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getDouble(_keyBalance) ?? 120432.05;
  }

  Future<void> setBalance(double value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_keyBalance, value);
  }

  // ---------------------------------------------------------------------------
  // User profile cache
  // ---------------------------------------------------------------------------

  Future<String?> getUserName() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keyUserName);
  }

  Future<void> setUserName(String name) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyUserName, name);
  }

  Future<String?> getUserEmail() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keyUserEmail);
  }

  Future<void> setUserEmail(String email) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyUserEmail, email);
  }

  // Multiple Registration persistence
  Future<List<Map<String, String>>> getRegisteredUsers() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonString = prefs.getString(_keyRegisteredUsers);
    if (jsonString == null) return [];
    try {
      final List<dynamic> decoded = jsonDecode(jsonString);
      return decoded.map((u) => Map<String, String>.from(u)).toList();
    } catch (e) {
      return [];
    }
  }

  Future<void> addRegisteredUser(Map<String, String> user) async {
    final prefs = await SharedPreferences.getInstance();
    final users = await getRegisteredUsers();
    
    // Update existing user if email matches, or add new one
    final index = users.indexWhere((u) => u['email'] == user['email']);
    if (index != -1) {
      users[index] = user;
    } else {
      users.add(user);
    }
    
    await prefs.setString(_keyRegisteredUsers, jsonEncode(users));
  }

  // ---------------------------------------------------------------------------
  // App settings
  // ---------------------------------------------------------------------------

  Future<bool> getNotificationsEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_keyNotificationsEnabled) ?? true;
  }

  Future<void> setNotificationsEnabled(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyNotificationsEnabled, value);
  }

  Future<int> getUnreadCount() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt(_keyUnreadCount) ?? 3;
  }

  Future<void> setUnreadCount(int count) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_keyUnreadCount, count);
  }

  Future<void> markAllRead() async => setUnreadCount(0);

  Future<int> getLastTab() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt(_keyLastTab) ?? 0;
  }

  Future<void> setLastTab(int index) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_keyLastTab, index);
  }

  Future<void> clear() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_keyUserName);
    await prefs.remove(_keyUserEmail);
    await prefs.remove(_keyLastTab);
    // Note: We DO NOT remove registration data or balance
  }
}
